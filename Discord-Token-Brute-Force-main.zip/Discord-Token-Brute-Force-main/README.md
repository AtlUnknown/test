# Discord-Token-Brute-Force

### **Discord Token Brute Force**
hack the account of the person of your choice just with his id to recover the id of the person you have to activate the developer mode

### **how to put developer mode**
To activate developer mode go to the settings of your discord account then go to appearance, go down then Developer mode activate

### **how to retrieve the id of the person**
Right click on the person where you want his id to copy the username.

![alt tag](https://cdn.discordapp.com/attachments/774757948496019479/775025739405852672/unknown.png)
